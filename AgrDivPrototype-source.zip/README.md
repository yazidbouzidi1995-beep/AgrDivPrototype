# AgrDiv Prototype (Demo only)
This is a starter Android project for a UI prototype. It is NOT the production system.
- No central database, no connection to the worker or director apps.
- No real stock, sales, transfer, request, leave, or notification operations.
- Demo forms do not persist business data.
## Build
The GitHub Actions workflow builds a debug APK when pushed to `main` or manually run with Actions > Build demo APK.
Upload this folder's contents to a GitHub repository from your phone. Then open Actions, run "Build demo APK" (or wait for push build), and download the artifact `AgrDivPrototype-debug-apk`.
